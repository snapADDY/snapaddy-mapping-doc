


class MainController {
  
  constructor($http, $scope) {
    this.base = 'https://api.snapaddy.com';
    this.apiKey = localStorage.getItem(this.base) || '';

    
    this.$http = $http;

    this.questionnaires = null;
    this.questionnaire = null;
    this.loading = false;

    $scope.$watch(() => this.apiKey, () => {
      localStorage.setItem(this.base, this.apiKey);
    });

    $scope.$watch(() => this.base, ()=> {
      this.questionnaires = null;
      this.questionnaire = null;
      this.loading = false;     
      this.apiKey = localStorage.getItem(this.base) || ''; 
    });
  
  }

  getAuthHeader() {
    return {
      'X-API-Token': this.apiKey
    };
  }

  getGroup(question) {
    return this.backendData.groups.find(g => g.id === question.groupId) || {};
  }

  getQuestion(questionOption) {
    return this.backendData.questions.find(q => q.id === questionOption.questionId) || {};
  }

  sameGroup(o1, o2) {
    if (!o1 || !o2) {
      return false;
    }

    try {
      return this.getQuestion(o1).groupId === this.getQuestion(o2).groupId;
    } catch (e) {
      return false;
    }
  }

  loadOptions(questionnaire) {
    const url = this.base + '/visitreport/v1/backend/questionnaires/' + questionnaire.id;
    this.$http({ method: 'GET', url: url, headers: this.getAuthHeader() }).then((response) => {
      this.backendData = response.data;

      this.options = this.backendData.questionOptions

        // sort by questionId
        .sort((q1, q2) => {
          const question1 = this.getQuestion(q1);
          const group1 = this.getGroup(question1);

          const question2 = this.getQuestion(q2);
          const group2 = this.getGroup(question2);

          if (group1.sequenceNumber === group2.sequenceNumber) {
            if (question1.column === question2.column) {
              return question1.sequenceNumber > question2.sequenceNumber ? 1 : -1;
            }
            return question1.column > question2.column ? 1 : -1;
          }

          if (group1.sequenceNumber > group2.sequenceNumber) {
            return 1;
          }
          return -1;

        });
    });
  }

  loadQuestionnaires() {
    this.loading = true;
    this.questionnaire = null;
    this.questionnaires = null;
    this.options = null;

    const url = this.base + '/visitreport/v1/questionnaire';
    this.$http({ method: 'GET', url: url, headers: this.getAuthHeader() }).then((response) => {
      this.questionnaires = response.data;
      if (this.questionnaires.length > 0) {
        this.questionnaire = this.questionnaires[0];
        this.loadData(this.questionnaire);
      }
    }).finally(() => {
      this.loading = false;
    });
  }

  saveOption(option) {
    option.value = (option.value || '').trim();
    const url = this.base + '/visitreport/v1/questionOption/' + option.id;
    this.$http({ method: 'PUT', url: url, headers: this.getAuthHeader(), data: option }).then((response) => {
      console.info('saved value: ' + option.value + ' for option(' + option.id + ') ' + (option.texts.de || option.texts.en))
    });
  }


  loadData(questionnaire) {
    this.questionnaire = questionnaire;
    this.options = null;
    this.loadOptions(questionnaire);
  }
}

angular.module('mappingTest', [])
  .controller('MainController', MainController);
