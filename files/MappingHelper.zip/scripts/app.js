class MainController {

  constructor($http, $scope) {
    this.env = localStorage.getItem('env') || 'prod'
    this.base = localStorage.getItem('base-url') || 'https://api.snapaddy.com';
    this.apiKey = localStorage.getItem(this.env) || '';
    this.devName = localStorage.getItem('devName') || '';
    this.orgName = '';

    this.$http = $http;

    this.questionnaires = null;
    this.questionnaire = null;
    this.loading = false;
    this.showUniqueIds = false;
    this.collapseOptions = false;
    this.detailedInformation = false;
    this.showType = 'active';
    this.numTemplates = {
      active: 0,
      draft: 0,
      archived: 0,
      master: 0
    };

    // if apikey changes -> save it to localstorage
    $scope.$watch(() => this.apiKey, () => {
      localStorage.setItem(this.env, this.apiKey);
    });

    // if env changes -> save url to localstorage
    $scope.$watch(() => this.base, () => {
      localStorage.setItem('base-url', this.base);
      localStorage.setItem('env', this.env);
    });

    // if devName changes -> save it to localstorage
    $scope.$watch(() => this.devName, () => {
      this.base = this.getURL();
      localStorage.setItem('devName', this.devName);
    });

    // if base changes -> reset data, load apiKey for new base from localstorage
    $scope.$watch(() => this.env, () => {
      this.base = this.getURL();
      this.questionnaires = null;
      this.questionnaire = null;
      this.loading = false;
      this.apiKey = localStorage.getItem(this.env) || '';

      // if base and apiKey are defined -> load questionnaires
      // this is also triggered initially, so when you reopen the view
      // and all necessary information are loaded from localstorage we directly fetch all questionnaires
      if (this.base && this.apiKey) {
        this.loadQuestionnaires();
      }
    });
  }

  getURL() {
    switch (this.env) {
      case 'prod':
        return 'https://api.snapaddy.com';
      case 'stg':
        return 'https://api.stg.snapaddy.com';
      case 'dev':
        return `https://api-${this.devName}.dev.snapaddy.com`
    }
  };

  getAuthHeader() {
    return {
      'X-API-Token': this.apiKey
    };
  }

  getGroup(question) {
    return this.backendData.groups.find(g => g.id === question.groupId) || {};
  }

  getQuestion(questionOption) {
    return this.backendData.questions.find(q => q.id === questionOption.questionId) || {};
  }

  sameGroup(o1, o2) {
    if (!o1 || !o2) {
      return false;
    }

    try {
      return this.getQuestion(o1).groupId === this.getQuestion(o2).groupId;
    } catch (e) {
      return false;
    }
  }

  loadOptions(questionnaire) {
    const url = this.base + '/visitreport/v1/backend/questionnaires/' + questionnaire.id;
    this.$http({ method: 'GET', url: url, headers: this.getAuthHeader() }).then((response) => {
      this.backendData = response.data;

      this.options = this.backendData.questionOptions

        // sort by questionId
        .sort((q1, q2) => {
          const question1 = this.getQuestion(q1);
          const group1 = this.getGroup(question1);

          const question2 = this.getQuestion(q2);
          const group2 = this.getGroup(question2);

          if (group1.sequenceNumber === group2.sequenceNumber) {
            if (question1.column === question2.column) {
              if (question1.sequenceNumber === question2.sequenceNumber) {
                return q1.sequenceNumber - q2.sequenceNumber;
              }
              return question1.sequenceNumber > question2.sequenceNumber ? 1 : -1;
            }
            return question1.column > question2.column ? 1 : -1;
          }

          if (group1.sequenceNumber > group2.sequenceNumber) {
            return 1;
          }
          return -1;

        });
    });
  }

  loadQuestionnaires() {
    this.loading = true;
    this.questionnaire = null;
    this.questionnaires = null;
    this.options = null;

    const url = this.base + '/visitreport/v1/questionnaire';
    this.$http({ method: 'GET', url: url, headers: this.getAuthHeader() })
      .then((response) => {
        this.questionnaires = response.data;
        if (this.questionnaires.length > 0) {
          this.questionnaires.sort(this.sortByStatus);
          this.numTemplates.active = this.questionnaires.filter(q => q.finalized && !q.archived).length;
          this.numTemplates.draft = this.questionnaires.filter(q => !q.finalized && !q.master).length;
          this.numTemplates.archived = this.questionnaires.filter(q => q.archived).length;
          this.numTemplates.master = this.questionnaires.filter(q => q.master).length;
          if (this.numTemplates.active === 0) {
            this.showType = 'all';
          }
          const firstVisibleQuestionnaire = this.questionnaires.find(q => this.isVisible(q));
          this.questionnaire = firstVisibleQuestionnaire;
          this.loadData(this.questionnaire);
        }
      }).finally(() => {
        this.loading = false;
      });

    const watchdogUrl = this.base + '/watchdog/v1/user/me';
    this.$http({ method: 'GET', url: watchdogUrl, headers: this.getAuthHeader() })
      .then(response => {
        this.orgName = response.data?.organization_name;
      })
      .catch(err => {
        console.error(err)
        this.orgName = '';
      });
  }

  saveOption(option) {
    option.value = (option.value || '').trim();
    const url = this.base + '/visitreport/v1/questionOption/' + option.id;
    this.$http({ method: 'PUT', url: url, headers: this.getAuthHeader(), data: option }).then((response) => {
      console.info('saved value: ' + option.value + ' for option(' + option.id + ') ' + (option.texts.de || option.texts.en));
    });
  }

  loadData(questionnaire) {
    this.questionnaire = questionnaire;
    this.options = null;
    this.loadOptions(questionnaire);
  }

  isVisible(questionnaire) {
    if (this.showType === 'all')
      return true;
    if (questionnaire.archived && this.showType !== 'archived')
      return false;
    if (!questionnaire.finalized && !questionnaire.master && this.showType !== 'draft')
      return false;
    if (questionnaire.finalized && !questionnaire.archived && this.showType !== 'active')
      return false;
    if (questionnaire.master && this.showType !== 'master')
      return false;
    return true;
  }

  sortByStatus(a, b) {
    var scoreA = 0, scoreB = 0;
    scoreA += (a.finalized ? 1 : 0);
    scoreB += (b.finalized ? 1 : 0);
    scoreA += (a.archived ? -2 : 0);
    scoreB += (b.archived ? -2 : 0);
    // sort by name or date?
    if (scoreA == scoreB)
      return a.titles.de.localeCompare(b.titles.de);
    return scoreB - scoreA;
  }

  selectQuestionnaire() {
    switch (this.showType) {
      case 'active':
        this.questionnaire = this.questionnaires.find(q => q.finalized && !q.archived);
        break;
      case 'draft':
        this.questionnaire = this.questionnaires.find(q => !q.finalized && !q.master);
        break;
      case 'archived':
        this.questionnaire = this.questionnaires.find(q => q.finalized && q.archived);
        break;
      case 'master':
        this.questionnaire = this.questionnaires.find(q => q.master);
        break;
      case 'all':
        return;
      default:
        break;
    }
    this.loadData(this.questionnaire);
  }

  getQuestionType(type) {
    const questionType = {
      0: 'SingleSelection',
      1: 'MultiSelection',
      2: 'Text',
      3: 'Textarea',
      4: 'Number',
      5: 'Date',
      6: 'Signature',
      7: 'TypeaheadSingleSelection',
      8: 'TypeaheadMultiSelection',
    }

    return questionType[type];
  }
}

angular.module('mappingTest', [])
  .controller('MainController', MainController);
